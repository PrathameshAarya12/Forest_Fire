# app.py

from flask import Flask, request, jsonify
from flask_cors import CORS
import logging
import data_prep


# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": "*"}})  # CORS fix

# --- API Endpoints ---

@app.route('/api/welcome', methods=['GET'])
def welcome():
    logger.info(f"Request received: {request.method} {request.path}")
    return jsonify({"message": "Welcome to the Uttarakhand Fire Risk Simulation API!"})

@app.route('/api/current_data', methods=['GET'])
def current_data():
    """Returns real-time current weather and hotspots."""
    logger.info(f"Request received: {request.method} {request.path} - Fetching real-time data.")

    weather = data_prep.get_current_weather()
    hotspots = data_prep.get_mock_hotspots()  # Keep mock hotspots for now, as NASA API key seems invalid

    return jsonify({
        "weather": weather,
        "hotspots": hotspots
    })

@app.route('/api/predict_simulation', methods=['POST'])
def predict_simulation():
    """Accepts user inputs and returns the hourly fire spread simulation."""
    logger.info(f"Request received: {request.method} {request.path} - Starting simulation.")
    
    try:
        data = request.get_json()
        
        # Get user inputs
        sim_temp = float(data.get('temp_c', 30.0))
        sim_humidity = float(data.get('humidity_perc', 25.0))
        sim_wind_speed = float(data.get('wind_speed', 10.0))
        hours_to_simulate = int(data.get('hours', 5))
        
        if hours_to_simulate > 10: hours_to_simulate = 10 # Safety limit
        
        results = data_prep.predict_fire_risk_and_spread(
            sim_temp, 
            sim_humidity, 
            sim_wind_speed, 
            hours_to_simulate
        )
        
        return jsonify(results)
        
    except Exception as e:
        logger.error(f"Error during simulation: {e}", exc_info=True)
        return jsonify({"status": "error", "message": f"Simulation failed: {str(e)}"}), 500

@app.route('/api/past_data', methods=['GET'])
def past_data():
    """Returns mock historical data for the Historical Tab."""
    return jsonify({
        "status": "Mock historical data provided.",
        "fires_per_year": [
            {"year": 2021, "count": 250},
            {"year": 2022, "count": 310},
            {"year": 2023, "count": 180}
        ],
        "avg_temp_vs_fires": [
            {"temp": "Low (10-20C)", "fires": 50},
            {"temp": "Mid (20-30C)", "fires": 150},
            {"temp": "High (>30C)", "fires": 300}
        ]
    })


if __name__ == '__main__':
    try:
        data_prep.MODEL
        print("\n--- Flask Server Starting on PORT 8000 ---")
        app.run(debug=True, host='0.0.0.0', port=8000) 
    except Exception as e:
        print("\nFATAL ERROR: Could not load model.pkl or grid_points.csv.")
        print("Please ensure you successfully ran 'python train_model.py'.")
        print(f"Details: {e}")