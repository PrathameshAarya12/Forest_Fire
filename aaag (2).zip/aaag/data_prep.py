# data_prep.py

import pandas as pd
import numpy as np
from joblib import load
from collections import defaultdict

# Load the trained model and grid data once at startup
MODEL = load('model.pkl')
GRID_DATA = pd.read_csv('grid_points.csv')
FEATURES = ['wind_speed', 'RH_index', 'temperature_2m', 'NDVI'] 

# --- Mock Data Functions (Replacing APIs) ---

def get_current_weather():
    """Fetches real-time weather data from OpenWeatherMap API for Dehradun."""
    import requests
    api_key = "0dceaf6f9ec1dc41dfeee959e94b2281"  # Primary API key
    url = f"https://api.openweathermap.org/data/2.5/weather?q=Dehradun&appid={api_key}&units=metric"
    try:
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            return {
                "temperature_c": data["main"]["temp"],
                "humidity_perc": data["main"]["humidity"],
                "wind_speed_kmh": data["wind"]["speed"] * 3.6,  # Convert m/s to km/h
                "status": "Real-time data from OpenWeatherMap."
            }
        else:
            # Fallback to second API key
            api_key = "c2d59ac4dc536c2851c1bd9d41b2107e"
            url = f"https://api.openweathermap.org/data/2.5/weather?q=Dehradun&appid={api_key}&units=metric"
            response = requests.get(url)
            if response.status_code == 200:
                data = response.json()
                return {
                    "temperature_c": data["main"]["temp"],
                    "humidity_perc": data["main"]["humidity"],
                    "wind_speed_kmh": data["wind"]["speed"] * 3.6,
                    "status": "Real-time data from OpenWeatherMap (fallback key)."
                }
            else:
                return get_mock_current_weather()  # Fallback to mock if both fail
    except Exception as e:
        logger.error(f"Error fetching weather data: {e}")
        return get_mock_current_weather()

def get_mock_current_weather():
    """Returns mock weather data for display in the Actual tab."""
    # Mock data based on a high-risk scenario
    return {
        "temperature_c": 28.5,
        "humidity_perc": 35,
        "wind_speed_kmh": 15.2,
        "status": "Mock Data - API failed."
    }

def get_mock_hotspots(count=5):
    """Returns mock hotspot locations for the map."""
    # Mocking few points in Uttarakhand region
    mock_fires = [
        {"lat": 30.06, "lon": 78.95, "frp": 65},
        {"lat": 30.35, "lon": 79.51, "frp": 80},
        {"lat": 30.50, "lon": 78.50, "frp": 70},
    ]
    return mock_fires

# --- Core Simulation Logic ---

def predict_fire_risk_and_spread(sim_temp, sim_humidity, sim_wind_speed, hours_to_simulate):
    """
    Predicts fire risk on the grid and simulates hourly spread.
    """
    df = GRID_DATA.copy()
    
    # 1. Apply User's Simulated Inputs to Base Features
    # Note: We assume sim_temp/humidity are absolute values provided by the user (not deltas)
    # We use the user's input directly for simulation realism.
    
    # Adjust features for prediction
    df['sim_wind_speed'] = sim_wind_speed
    df['sim_temperature_2m'] = sim_temp + 273.15 # Convert C to Kelvin for model input
    df['sim_RH_index'] = sim_humidity 
    
    # Prepare features for the model
    X_sim = df[[
        'sim_wind_speed', 
        'sim_RH_index', 
        'sim_temperature_2m', 
        'NDVI'
    ]].fillna(df[FEATURES].mean()) # Use original NDVI, fill missing wind/temp values if any

    # Rename columns to match the trained model's feature names
    X_sim.columns = FEATURES 
    
    # 2. Initial Prediction (Time 0)
    initial_risk_proba = MODEL.predict_proba(X_sim)[:, 1]
    df['risk_proba'] = initial_risk_proba
    
    # --- 3. Cellular Automata (CA) Spread Simulation ---
    
    # Threshold for initial ignition (Fire will start if risk is high enough)
    IGNITION_THRESHOLD = 0.65 
    
    # Threshold for spread to a neighbor (Lower than ignition)
    SPREAD_THRESHOLD = 0.40 
    
    # Simplified Wind Bias: Wind increases spread probability downwind
    WIND_BIAS = 0.20
    
    # Use a dictionary to track the state of each cell: { (lat, lon): max_risk_at_any_hour }
    current_state = {}
    
    # Initialize with all cells and their initial risk
    for index, row in df.iterrows():
        key = (round(row.latitude, 2), round(row.longitude, 2))
        current_state[key] = row.risk_proba
        
    # Store hourly results
    hourly_spread_results = []
    
    for t in range(1, hours_to_simulate + 1):
        
        # Start with a deep copy of the state from the previous hour
        next_state = current_state.copy()
        new_fires_count = 0
        
        # Iterate over all cells that currently have a risk above the spread threshold
        # We check cells that were highly risky/ignited in previous hours.
        spreading_cells = [(k, v) for k, v in current_state.items() if v > SPREAD_THRESHOLD]
        
        for (lat, lon), risk_at_t_minus_1 in spreading_cells:
            
            # --- Simplistic Spread Logic ---
            # Neighbors offsets (8 directions)
            offsets = [(-0.02, 0), (0.02, 0), (0, -0.02), (0, 0.02), (-0.02, -0.02), (-0.02, 0.02), (0.02, -0.02), (0.02, 0.02)]
            
            for dlat, dlon in offsets:
                neighbor_lat = round(lat + dlat, 2)
                neighbor_lon = round(lon + dlon, 2)
                neighbor_key = (neighbor_lat, neighbor_lon)
                
                # Only try to ignite cells that haven't burned or don't have high risk yet
                if next_state.get(neighbor_key, 0) <= risk_at_t_minus_1:

                    # Find the nearest grid point's features (mock the neighbor's environment)
                    # For simplicity, we use the average features of the entire grid
                    neighbor_features = df[FEATURES].mean() 
                    
                    # Predict potential risk for the neighbor
                    X_neighbor = pd.DataFrame([neighbor_features], columns=FEATURES)
                    neighbor_proba = MODEL.predict_proba(X_neighbor)[:, 1][0]
                    
                    # Apply Wind Bias (Mocking wind direction influence)
                    # Assuming wind is roughly West-to-East (Positive Lon change) for Uttarakhand
                    is_downwind = dlon > 0 # If moving East/North-East/South-East
                    wind_boost = WIND_BIAS if is_downwind else 0
                    
                    final_spread_risk = neighbor_proba + wind_boost
                    
                    # If neighbor risk crosses the spread threshold (or ignition threshold)
                    if final_spread_risk > SPREAD_THRESHOLD:
                        # The neighbor's new risk is the max of its old risk or the new spread risk
                        new_risk_value = min(1.0, max(next_state.get(neighbor_key, 0), final_spread_risk))
                        
                        if new_risk_value > next_state.get(neighbor_key, 0):
                            next_state[neighbor_key] = new_risk_value
                            new_fires_count += 1
        
        current_state = next_state
        
        # Format the current hour's state for the frontend
        hourly_data = []
        for (lat, lon), risk in current_state.items():
            if risk > SPREAD_THRESHOLD: # Only send points that are actively risky/spreading
                 hourly_data.append({"lat": lat, "lon": lon, "risk": risk, "hour": t})
        
        hourly_spread_results.append({
            "hour": t,
            "data": hourly_data,
            "new_cells_risky": new_fires_count
        })
        
        if new_fires_count == 0:
            break
            
    # 4. Final Formatting for Frontend
    initial_map_data = [{"lat": row.latitude, "lon": row.longitude, "risk": row.risk_proba} for index, row in df.iterrows()]
    
    return {
        "initial_prediction": initial_map_data,
        "spread_simulation": hourly_spread_results,
        "status": "Simulation successful (Mock APIs)."
    }