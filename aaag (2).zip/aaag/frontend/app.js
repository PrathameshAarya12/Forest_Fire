// frontend/App.js (Port Fixed to 8000)
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import './index.css';

// CRITICAL FIX: Leaflet default icon fix
if (L && L.Icon && L.Icon.Default) {
    delete L.Icon.Default.prototype._getIconUrl;
    L.Icon.Default.mergeOptions({
        iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
        iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
        shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
    });
}

// --- PORT FIX: Changed from 5000 to 8000 (CORRECTED LINE) ---
const API_BASE_URL = 'http://127.0.0.1:8000/api'; // <--- FIX HERE: Changed from 5000 to 8000
const INITIAL_VIEW = [30.0668, 79.0193]; 

// --- Helper Component: Risk Heatmap Overlay ---
const RiskHeatmap = ({ data, spreadHour }) => {
    const map = useMap();

    useEffect(() => {
        if (!data || data.length === 0) return;

        const currentHourData = data
            .filter(h => h.hour <= spreadHour)
            .flatMap(h => h.data);

        map.eachLayer(layer => {
            if (layer._heatmap) {
                map.removeLayer(layer);
            }
        });

        currentHourData.forEach(point => {
            const risk = point.risk;
            let color;
            if (risk > 0.8) color = 'rgba(255, 0, 0, 0.8)';       
            else if (risk > 0.6) color = 'rgba(255, 165, 0, 0.7)'; 
            else if (risk > 0.45) color = 'rgba(255, 255, 0, 0.6)'; 
            else color = 'rgba(0, 0, 0, 0)'; 

            if (risk > 0.4) {
                const size = 15 + (risk * 20); 
                
                const customIcon = L.divIcon({
                    className: 'risk-marker',
                    html: `<div style="background-color:${color}; width:${size}px; height:${size}px; border-radius:50%; box-shadow: 0 0 5px ${color};"></div>`,
                    iconSize: [size, size],
                    iconAnchor: [size / 2, size / 2],
                });

                const marker = L.marker([point.lat, point.lon], { icon: customIcon });
                marker._heatmap = true; 
                marker.addTo(map).bindPopup(`Spread Hour ${point.hour}: Risk ${risk.toFixed(2)}`);
            }
        });

    }, [data, spreadHour, map]); 

    return null;
};


// --- Main App Component ---
const App = () => {
    const [activeTab, setActiveTab] = useState('simulation');
    const [hotspots, setHotspots] = useState([]);
    const [currentWeather, setCurrentWeather] = useState({});
    const [simulationData, setSimulationData] = useState(null);
    const [loading, setLoading] = useState(false);
    
    const [temp, setTemp] = useState(30);
    const [humidity, setHumidity] = useState(25);
    const [windSpeed, setWindSpeed] = useState(10);
    const [hours, setHours] = useState(5);
    const [spreadHour, setSpreadHour] = useState(0); 

    useEffect(() => {
        axios.get(`${API_BASE_URL}/current_data`)
            .then(res => {
                setCurrentWeather(res.data.weather);
                setHotspots(res.data.hotspots);
            })
            .catch(err => console.error("Error fetching current data:", err));
    }, []); 
    
    const runSimulation = () => {
        setLoading(true);
        setSpreadHour(0); 
        setSimulationData(null); 

        axios.post(`${API_BASE_URL}/predict_simulation`, {
            temp_c: parseFloat(temp),
            humidity_perc: parseFloat(humidity),
            wind_speed: parseFloat(windSpeed),
            hours: parseInt(hours)
        })
        .then(res => {
            setSimulationData(res.data);
            setSpreadHour(1); 
            setLoading(false);
        })
        .catch(err => {
            // Error alert message updated to reflect the new port 8000
            console.error("Simulation failed! Check if the Flask server is running on port 8000. Error details:", err);
            alert("Backend Error! Check if Flask server is running on http://127.0.0.1:8000 and CORS is enabled.");
            setLoading(false);
        });
    };
    
    const hourlySummary = simulationData?.spread_simulation.find(s => s.hour === spreadHour);

    return (
        <div className="min-h-screen bg-gray-100 p-4 font-sans">
            <header className="bg-white p-4 rounded-lg shadow-md mb-4">
                <h1 className="text-3xl font-bold text-red-700">🏔️ Uttarakhand Forest Fire Simulator</h1>
                <p className="text-sm text-gray-600">ML Model-based Risk & Spread Prediction (Using Local Mock Data)</p>
            </header>

            <div className="flex space-x-2 mb-4">
                <button onClick={() => setActiveTab('actual')} 
                        className={`py-2 px-4 rounded-t-lg font-medium transition-colors ${activeTab === 'actual' ? 'bg-red-600 text-white shadow-lg' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}>
                    1. Current Risk
                </button>
                <button onClick={() => setActiveTab('simulation')} 
                        className={`py-2 px-4 rounded-t-lg font-medium transition-colors ${activeTab === 'simulation' ? 'bg-red-600 text-white shadow-lg' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}>
                    2. Simulation & Spread
                </button>
                <button onClick={() => setActiveTab('historical')} 
                        className={`py-2 px-4 rounded-t-lg font-medium transition-colors ${activeTab === 'historical' ? 'bg-red-600 text-white shadow-lg' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}>
                    3. Historical Analysis
                </button>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-xl">
                {activeTab === 'actual' && (
                    <div className="space-y-4">
                <h2 className="text-xl font-semibold mb-3">Current Conditions (Dehradun Area)</h2>
                        <div className="p-3 bg-blue-50 border-l-4 border-blue-400 text-blue-800 rounded-md">
                            <p>🌡️ Temp: {currentWeather.temperature_c}°C | 💧 Humidity: {currentWeather.humidity_perc}% | 🌬️ Wind: {currentWeather.wind_speed_kmh} km/h</p>
                            <p className="text-sm italic mt-1">Status: {currentWeather.status}</p>
                        </div>
                        <MapContainer center={INITIAL_VIEW} zoom={9} style={{ height: '70vh', width: '100%', borderRadius: '8px', boxShadow: '0 4px 6px rgba(0,0,0,0.1)' }}>
                            <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" attribution='&copy; OpenStreetMap contributors'/>
                            {hotspots.map((fire, index) => (
                                <Marker key={index} position={[fire.lat, fire.lon]}>
                                    <Popup>Mock Hotspot | FRP: {fire.frp}</Popup>
                                </Marker>
                            ))}
                        </MapContainer>
                    </div>
                )}
                
                {activeTab === 'simulation' && (
                    <div className="simulation-tab">
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6 p-4 bg-gray-50 rounded-lg shadow-inner">
                            <input type="number" value={temp} onChange={(e) => setTemp(e.target.value)} placeholder="Temp (°C)" className="p-2 border rounded-md shadow-sm" />
                            <input type="number" value={humidity} onChange={(e) => setHumidity(e.target.value)} placeholder="Humidity (%)" className="p-2 border rounded-md shadow-sm" />
                            <input type="number" value={windSpeed} onChange={(e) => setWindSpeed(e.target.value)} placeholder="Wind Speed (km/h)" className="p-2 border rounded-md shadow-sm" />
                            <input type="number" value={hours} onChange={(e) => setHours(e.target.value)} min="1" max="10" placeholder="Hours to Simulate" className="p-2 border rounded-md shadow-sm" />
                            
                            <button onClick={runSimulation} 
                                className={`col-span-4 py-2 rounded-md font-bold transition-colors shadow-md ${loading ? 'bg-gray-400' : 'bg-green-600 text-white hover:bg-green-700'}`}
                                disabled={loading}>
                                {loading ? 'Simulating... ⏳' : 'Start Fire Spread Simulation'}
                            </button>
                        </div>
                        
                        {loading && <p className="text-center text-lg text-blue-600 my-4">Calculating risk and spread simulation...</p>}

                        {simulationData && (
                            <div className="results-panel space-y-4">
                                <div className="p-3 bg-red-50 border-l-4 border-red-400 rounded-md">
                                    <label className="block text-gray-700 font-semibold mb-2">Time Elapsed (Hours): <span className="text-red-700 text-lg">{spreadHour}</span></label>
                                    <input 
                                        type="range" 
                                        min="1" 
                                        max={simulationData.spread_simulation.length} 
                                        value={spreadHour} 
                                        onChange={(e) => setSpreadHour(parseInt(e.target.value))}
                                        className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                                    />
                                </div>

                                <MapContainer center={INITIAL_VIEW} zoom={9} style={{ height: '70vh', width: '100%', borderRadius: '8px', boxShadow: '0 4px 10px rgba(0,0,0,0.15)' }}>
                                    <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                                    <RiskHeatmap 
                                        data={simulationData.spread_simulation} 
                                        spreadHour={spreadHour}
                                    />
                                </MapContainer>
                                
                                {hourlySummary && (
                                    <div className="summary mt-4 p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                                        <h4 className="font-bold text-lg text-yellow-800">🔥 Hour {spreadHour} Summary:</h4>
                                        <p>New Risky Cells (Spread): <span className="font-semibold text-red-600">{hourlySummary.new_cells_risky}</span></p>
                                        <p>Total High-Risk Cells (Accumulated): {hourlySummary.data.length}</p>
                                        <p className="text-sm italic">Note: Simulation spread is influenced by Wind Speed and initial risk predicted by the ML model.</p>
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                )}
                
                {activeTab === 'historical' && (
                    <div className="historical-tab p-4 text-center">
                        <h2 className="text-xl font-semibold mb-3">Historical Data (Analysis Tab)</h2>
                        <p className="text-gray-600">This tab would show graphs (using Chart.js or similar) of past data (Fire Count per Year, Temp vs. Fire correlation, etc.) fetched from the **`/api/past_data`** endpoint. (Currently displays mock data text).</p>
                        <div className="mt-4 p-6 bg-gray-50 rounded-lg">
                            <p>Mock data fetched from backend includes:</p>
                            <ul className="list-disc list-inside text-left mx-auto max-w-sm mt-2">
                                <li>Fires per Year (2021-2023)</li>
                                <li>Average Temperature vs. Fire Count</li>
                            </ul>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default App;