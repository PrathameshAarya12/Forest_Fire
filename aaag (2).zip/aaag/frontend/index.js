// frontend/index.js (Final Corrected Version)
import React from 'react';
import ReactDOM from 'react-dom/client';
// FIX: Ab App component ko .js extension se import kar rahe hain
import App from './App.js'; 

const rootElement = document.getElementById('root');
const root = ReactDOM.createRoot(rootElement);

root.render(
    <React.StrictMode>
        <App />
    </React.StrictMode>
);