import pandas as pd
import numpy as np
import json
import os 
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from joblib import dump

# --- Configuration (File Names) ---
HOTSPOTS_FILE = 'uttarakhand_firms_hotspots_10y_final.csv' 
WEATHER_FILE = 'uttarakhand_era5_weather_10y_fixed.csv'
NDVI_FILE = 'uttarakhand_ndvi_data_10y_final.csv'

# --- Output Files ---
MODEL_OUTPUT = 'model.pkl'
GRID_POINTS_OUTPUT = 'grid_points.csv'

# --- 1. Data Loading and Parsing ---
print("1. Loading and Parsing CSVs...")

# Check if files exist
if not all(os.path.exists(f) for f in [WEATHER_FILE, NDVI_FILE]):
    print("ERROR: Weather or NDVI file not found. Check your file names and path.")
    exit()

try:
    # Load data
    df_weather = pd.read_csv(WEATHER_FILE)
    df_ndvi = pd.read_csv(NDVI_FILE)
except Exception as e:
    print(f"ERROR: Could not read a CSV file. Details: {e}")
    exit()

# CRITICAL: Parse .geo column to get Lat/Lon 
def extract_lat_lon(geo_str):
    try:
        data = json.loads(geo_str)
        # Coordinates are typically [Lon, Lat] for Point type data
        return pd.Series([data['coordinates'][1], data['coordinates'][0]]) 
    except:
        return pd.Series([np.nan, np.nan])

# Apply parsing to dataframes
df_weather[['latitude', 'longitude']] = df_weather['.geo'].apply(extract_lat_lon)
df_ndvi[['latitude', 'longitude']] = df_ndvi['.geo'].apply(extract_lat_lon)

df_weather.dropna(subset=['latitude', 'longitude'], inplace=True)
df_ndvi.dropna(subset=['latitude', 'longitude'], inplace=True)


# --- 2. Data Merging (CRITICAL FIX: Using low precision rounding) ---
ROUND_DECIMALS = 2 # <--- CRITICAL FIX: Precision set to 2 decimals

df_w = df_weather[['latitude', 'longitude', 'temperature_2m', 'dewpoint_temperature_2m', 'u_component_of_wind_10m', 'v_component_of_wind_10m']].copy()
df_n = df_ndvi[['latitude', 'longitude', 'NDVI']].copy() 

# Add rounded columns for merging
df_w['lat_round'] = df_w['latitude'].round(ROUND_DECIMALS)
df_w['lon_round'] = df_w['longitude'].round(ROUND_DECIMALS)
df_n['lat_round'] = df_n['latitude'].round(ROUND_DECIMALS)
df_n['lon_round'] = df_n['longitude'].round(ROUND_DECIMALS)


# Merge on the rounded coordinates ('inner' merge means only exact matches are kept)
df_final = pd.merge(
    df_w, 
    df_n[['lat_round', 'lon_round', 'NDVI']], 
    on=['lat_round', 'lon_round'], 
    how='inner'
)

# Use original latitude/longitude for final output and prediction grid
df_final.drop(columns=['lat_round', 'lon_round'], inplace=True) 
df_final.drop_duplicates(subset=['latitude', 'longitude'], inplace=True)
df_final.fillna(df_final.mean(numeric_only=True), inplace=True) 

print(f"2. Data Merging done. Total samples: {len(df_final)}")


# --- 3. Feature Engineering and Target Creation ---
print("3. Feature Engineering and Target Creation...")

# Feature 1: Wind Speed (from U and V components)
df_final['wind_speed'] = np.sqrt(df_final['u_component_of_wind_10m']**2 + df_final['v_component_of_wind_10m']**2)

# Feature 2: Relative Humidity (Simplified RH index)
df_final['temp_dewpoint_diff'] = df_final['temperature_2m'] - df_final['dewpoint_temperature_2m']
df_final['RH_index'] = 100 - (10 * df_final['temp_dewpoint_diff']) 
df_final['RH_index'] = df_final['RH_index'].clip(0, 100)

# CRITICAL: TARGET LABEL CREATION (Proxy target based on extreme weather conditions)
HIGH_TEMP_K = 295  # Approx 22°C (hot season base)
LOW_RH_INDEX = 50 
MODERATE_WIND = 0.5 

df_final['fire_occurred'] = np.where(
    (df_final['temperature_2m'] > HIGH_TEMP_K) & 
    (df_final['RH_index'] < LOW_RH_INDEX) &
    (df_final['wind_speed'] > MODERATE_WIND), 
    1, # Fire likely (1)
    0  # No fire (0)
)

print(f"Proxy Fire Target: {df_final['fire_occurred'].sum()} Fire points created out of {len(df_final)}.")

# Final Features List
FEATURES = [
    'wind_speed', 
    'RH_index', 
    'temperature_2m', 
    'NDVI'
]
TARGET = 'fire_occurred'

X = df_final[FEATURES]
Y = df_final[TARGET]

# Check for samples to ensure training can happen
if len(df_final) == 0:
    print("\nERROR: Merging still failed. Check if your CSV files contain overlapping Lat/Lon data.")
    exit()
if Y.sum() == 0 or len(Y) < 20:
    print("\nWARNING: Target variable is highly imbalanced or empty. Training might not be reliable.")
    # But we will still proceed if we have some samples
    if len(Y) < 20:
        print("FATAL ERROR: Less than 20 unique samples after merging. Cannot train.")
        exit()


# --- 4. Model Training ---
print("4. Training Random Forest Classifier...")
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, random_state=42, stratify=Y)

model = RandomForestClassifier(n_estimators=100, max_depth=10, random_state=42)
model.fit(X_train, Y_train)

score = model.score(X_test, Y_test)
print(f"Model Accuracy on Test Set: {score:.4f}")

# --- 5. Save Model and Grid Points ---
print("5. Saving Model and Grid Data...")

# Save the trained model
dump(model, MODEL_OUTPUT)
print(f"ML Model saved to {MODEL_OUTPUT}")

# Save the necessary grid points for the Flask app's simulation feature
df_grid = df_final[['latitude', 'longitude'] + FEATURES].copy()
df_grid.to_csv(GRID_POINTS_OUTPUT, index=False)
print(f"Grid points saved to {GRID_POINTS_OUTPUT}")

print("\n--- Training Complete! ---")